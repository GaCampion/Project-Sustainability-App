import React, { useEffect, useState } from "react";
import style from "./style.css";
import food from "./Images/food.jpg";

function Recipe() {
  // State variables for data, loading status, error, and search term
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    async function fetchData() {
      // Fetch data from Spoonacular API based on the search term endpoint. Filtering is done on API side so endpoint edits needed to make searching flexible for users.
      const URL = `https://api.spoonacular.com/recipes/complexSearch?number=30&query=${searchTerm}&fillIngredients=true&addRecipeInformation=true&addRecipeNutrition=true&apiKey=e1403e0599ec4c00b50ae8a2fa60ff0a`;
      try {
        const response = await fetch(URL);
        const food = await response.json();
        setLoading(true);
        setData(food.results);
      } catch (error) {
        setError(error);
        setLoading(false);
      }
    }
    //The effect has dependency on the 'searchTerm' variable.
    fetchData();
  }, [searchTerm]);

  if (error) {
    return <h1>Opps! An error has occurred: {error.toString()}</h1>;
  } else if (loading === false) {
    return <h1>Waiting for the recipe data ...... waiting....</h1>;
  } else {
    return (
      <>
        &nbsp;
        <div className="container-fluid text-center">
          <img class="img-fluid rounded small-image" src={food} alt="foodImg" />
          &nbsp;
          <div class=" active-cyan-4 mb-4 container">
            &nbsp;
            {/*(search box for user to input their search term*/}
            <input
              class="form-control"
              type="text"
              aria-label="Search"
              placeholder="What food items do you have leftover?"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          {/*Conditional rendering based on search term being present*/}
          {/*FoodRecipeComponent is proping the data*/}
          {searchTerm && <FoodRecipeComponent responseData={data} />}
        </div>
      </>
    );
  }
}

function FoodRecipeComponent(props) {
  // Function to check and filter out duplicate ingredients
  //*hasOwnProperty function needed to research from MBN webdocs and programiz as had issue with duplicate object properties being mapped by extendedIngredients*/

  const checkIngredients = (recipe) => {
    const uniqueIngredients = {};
    return recipe.extendedIngredients.filter((ingredient) => {
      if (!uniqueIngredients.hasOwnProperty(ingredient.original)) {
        uniqueIngredients[ingredient.original] = true;
        return true;
      }
      return false;
    });
  };

  //needed to define data like this as length needed to be defined when empty or else it produced length error when empty after initial search.
  const responseData = props.responseData || [];
  let numberResults = responseData.length;
  return (
    <div className="container mt-4">
      <h1 className="mb-3 text-center">Here are your recipes!</h1>
      <h2 className="mb-3 text-center">
        {numberResults > 0 &&
          `You have ${numberResults} recipes from your search.`}
      </h2>
      <div className="table-responsive">
        {/* Display a table with recipe information */}
        <table className="table table-hover table-striped table-bordered border-secondary ">
          <thead className="table-info text-center">
            <tr>
              <th>Recipe</th>
              <th>Photo</th>
              <th>Source</th>
              <th>Servings</th>
              <th>Health Score</th>
              <th>Ingredients</th>
            </tr>
          </thead>
          <tbody>
            {responseData.map((recipe, index) => (
              <tr key={index}>
                <td>
                  <strong>{recipe.title}</strong>
                </td>
                <td>
                  <img
                    src={recipe.image}
                    alt={recipe.title}
                    className="img-fluid rounded"
                  />
                </td>

                <td>
                  <a href={recipe.sourceUrl} target="_blank">
                    Visit Source
                  </a>
                </td>
                <td>
                  <strong>{recipe.servings}</strong>
                </td>
                <td>
                  <strong>{recipe.healthScore}</strong>
                </td>
                <td>
                  {/*Nested map funciton due to the structure of the API data*/}
                  <ul>
                    {checkIngredients(recipe).map((ingredient, index) => (
                      <li key={index}>
                        {ingredient.original}
                        &nbsp; &nbsp;
                      </li>
                    ))}
                  </ul>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default Recipe;

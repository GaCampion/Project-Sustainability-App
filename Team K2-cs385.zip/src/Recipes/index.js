import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";

import Recipe from "./Recipe";

//Bootstrap css
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min";
const rootElement = document.getElementById("root");
const root = createRoot(rootElement);

root.render(
  <StrictMode>
    <Recipe />
  </StrictMode>
);

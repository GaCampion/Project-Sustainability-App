import Styles from "./home.css";
import React from "react";

//Importing Images from the Folder HomePage
import pancake from "./Pancake.jpg";
import Agarden from "./Agarden.jpg";
import compost from "./Acompost.jpg";

function Home() {
  return (
    <div>
      {/* Using html header, main, paragraphs & a footer to display description of website with images
          Bootstrap used for layout & styling and CSS to make all images the same size.
       */}
      <header>
        <h2 class="display-3">GroCycle</h2>
        <hr />
        <img src={Agarden} alt="carrot" className="img-fluid homeImg" />
        <p>
          Be inspired to get cooking, grow your own fruit and vegetables! We
          have unique recipes and ways of composting raw materials.
        </p>
        {/* Using bootstrap to make our link look like a button, 
            it makes button blue, text white and removes the underline */}
        <div className="btn btn-primary">
          <a
            href="/Garden"
            className="text-white"
            style={{ textDecoration: "none" }}
          >
            Gardening
          </a>
        </div>
      </header>
      <hr />
      <main>
        <h4>Connecting you with unique recipes based on your leftovers.</h4>
        <img src={pancake} alt="pancake Image" className="img-fluid homeImg" />
        <p>
          Find unique recipes by independently using the ingredients at your
          disposal, for you and your family to enjoy.
        </p>
        {/* Using bootstrap to make our link look like a button, 
            it makes button blue, text white and removes the underline */}
        <div className="btn btn-primary">
          <a
            href="/Recipe"
            className="text-white"
            style={{ textDecoration: "none" }}
          >
            Recipes
          </a>
        </div>
      </main>
      <hr />
      <footer>
        <h4>Composting Raw Materials</h4>
        <img src={compost} alt="Compost Image" className="img-fluid homeImg" />
        <p>Implement ways to compost your raw materials</p>
        {/* Using bootstrap to make our link look like a button, 
            it makes button blue, text white and removes the underline */}
        <div className="btn btn-primary">
          <a
            href="/CompostBinMain"
            className="text-white"
            style={{ textDecoration: "none" }}
          >
            Compost Bin
          </a>
        </div>
      </footer>
    </div>
  );
}
export default Home;

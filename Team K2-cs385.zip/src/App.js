//Importing main library for setting up the router
//In Codesandbox you will also need to add it in the dependencies to avoid errors
import React from "react";
import {
  BrowserRouter as Router,
  Route,
  Link,
  Routes,
  Navigate,
} from "react-router-dom";

//Importing the main pages to add in the navigation bar
import Home from "./HomePage/Home";
import Garden from "./Gardening/Garden";
import CompostBinMain from "./Compost/CompostBinMain";
import Recipe from "./Recipes/Recipe";

function App() {
  return (
    // This code uses bootstrap to center the tabs, and for styling classes.
    // Using an unordered list to display the main pages in the navigation tabs
    <Router>
      <div class="container mt-0">
        <nav>
          <ul class="nav nav-tabs d-flex justify-content-center">
            <li class="nav-item">
              <Link to="/Home" className="nav-link">
                Home
              </Link>
            </li>
            <li class="nav-item">
              <Link to="/Recipe" className="nav-link">
                Recipes
              </Link>
            </li>
            <li class="nav-item">
              <Link to="/CompostBinMain" className="nav-link">
                Compost Bin
              </Link>
            </li>
            <li class="nav-item">
              <Link to="/Garden" className="nav-link">
                Gardening
              </Link>
            </li>
          </ul>
        </nav>
        <Routes>
          {/* 
              The Route links all pages for user navigation 
              Allows for the pages to be rendered once the user clicks on them.
              The element={<Navigate to="/home" />} sets the home page as the default.
          */}
          <Route path="/" element={<Navigate to="/home" />} />
          <Route path="/Home" element={<Home />} />
          <Route path="/Recipe" element={<Recipe />} />
          <Route path="/CompostBinMain" element={<CompostBinMain />} />
          <Route path="/Garden" element={<Garden />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;

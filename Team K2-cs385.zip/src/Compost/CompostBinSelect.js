import React, { useState, useEffect } from "react";

function CompostBinSelector(props) {
  // State variables to manage selected compost bin type, the selected bin data, loading, and errors
  const [selectedBin, setSelectedBin] = useState("");
  const [compostBins, setCompostBins] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Function to handle the selection change in the dropdown
  function handleListChange(event) {
    const selectedType = event.target.value;
    if (selectedType === "Select a type") {
      setSelectedBin("");
    } else {
      // Find the selected bin in the list of compost bins
      const bin = compostBins.find((bin) => bin.Type === selectedType);
      setSelectedBin(bin);
    }
  }

  // Use Effect to fetch compost bin data when the component mounts
  useEffect(() => {
    async function fetchData() {
      const URL =
        "https://raw.githubusercontent.com/GaCampion/Project-Sustainability-App/main/COMPOSTBINS.json";
      try {
        const response = await fetch(URL);
        const bins = await response.json();
        setLoading(true);
        setCompostBins(bins);
      } catch (error) {
        setError(error);
        setLoading(false);
      }
    }

    fetchData();
  }, []);

  if (error) {
    return <h1>Oops! An error has occurred: {error.toString()}</h1>;
  } else if (!loading) {
    return <h1>Waiting for the compost bin data... waiting...</h1>;
  } else {
    // Render the dropdown to select compost bin type and details of the selected bin
    return (
      <>
        <form>
          <br /> <br />
          <select
            class="form-select form-select mb-3"
            aria-label=".form-select example"
            onChange={handleListChange}
            value={selectedBin ? selectedBin.Type : "Select a type"}
          >
            <option>Select a type</option>
            {compostBins.map((bin, index) => (
              <option key={index} value={bin.Type}>
                <strong> {bin.Type} </strong>
              </option>
            ))}
          </select>
        </form>
        {/*Condiitional rendering based on selected bin*/}
        {selectedBin && (
          <div className="card-container">
            <div className="item">
              <div className="image-container">
                <img
                  src={selectedBin.Image}
                  alt={selectedBin.Type}
                  className="image"
                />
              </div>
              <div>
                <div>
                  <h3>Description</h3>
                  <p>{selectedBin.Description}</p>
                </div>
                <div>
                  <h3>Size</h3>
                  <p>{selectedBin.Size}</p>
                </div>
                <div>
                  <h3>Material</h3>
                  <p>{selectedBin.Material}</p>
                </div>
                <div>
                  <h3>Best Use</h3>
                  <p>{selectedBin["Best Use"]}</p>
                </div>
                <div>
                  <h3>Pros</h3>
                  <p>{selectedBin.Pros}</p>
                </div>
                <div>
                  <h3>Cons</h3>
                  <p>{selectedBin.Cons}</p>
                </div>
                <div>
                  <h3>Maintenance</h3>
                  <p>{selectedBin.Maintenance}</p>
                </div>
              </div>
            </div>
          </div>
        )}
        <br /> <br />
      </>
    );
  }
}
export default CompostBinSelector;

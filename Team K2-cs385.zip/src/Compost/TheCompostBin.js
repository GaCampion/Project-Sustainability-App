function CompostBin(props) {
  return (
    <>
      <hr />
      <h1>
        Your Current Compost Bin has : <b>{props.compostBin.length}</b> food
        items
      </h1>
      <div className="table-responsive">
        <table className="table table-hover table-striped table-bordered">
          <thead className="table-success">
            <tr>
              <th>Food</th>
              <th>ID</th>
              <th>Category</th>
              <th>Decomposition Time (days)</th>
              <th>Compostability Rating</th>
              <th>Carbon-to-Nitrogen Ratio (C:N)</th>
              <th>Environmental Impact Rating</th>
              <th>Picture</th>
              <th>Remove Item</th>
            </tr>
          </thead>
          <tbody>
            {/* Map through each item in the compost bin and create a table row for each */}
            {props.compostBin.map((c, index) => (
              <tr key={index}>
                <td>
                  <b>{c.Name}</b>
                </td>
                <td>
                  <b>{c.ID}</b>
                </td>
                <td>
                  <b>{c.Category}</b>
                </td>
                <td>
                  <b>{c["Decomposition Time (days)"]}</b>
                </td>
                <td>
                  <b>{c["Compostability Rating"]}</b>
                </td>
                <td>
                  <b>{c["Carbon-to-Nitrogen Ratio (C:N)"]}</b>
                </td>
                <td>
                  <b>{c["Environmental Impact Rating"]}</b>
                </td>
                <td>
                  <img src={c.Image} className="table-img " alt="Your Image" />
                </td>
                <td>
                  {/* Create a button to remove the item from the compost bin, proping the remove functionality from the parent component*/}
                  <button
                    className="btn btn-warning btn-sm"
                    onClick={() => props.remove(c)}
                  >
                    Remove
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}

export default CompostBin;

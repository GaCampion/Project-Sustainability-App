import React, { useEffect, useState } from "react";
import styles from "./styles.css";
import CompostResults from "./CompostResults.js";
// import ShowcompostCategory from "./ShowCompostCategory";
import CompostBinSelector from "./CompostBinSelect.js";
import CompostBin from "./TheCompostBin.js";
import SummariseBin from "./SummaryBin.js";

//Import Images
import CompostBinImg from "./Images/CompostBin.jpg";

function CompostBinMain() {
  //State variable to manage the compost data.
  const [data, setData] = useState([]);
  //State variable to manage search term by user
  const [searchTerm, setSearchTerm] = useState("");
  //State variable to manage loading.
  const [loading, setLoading] = useState(false);
  //State variable to manage errors.
  const [error, setError] = useState(null);
  //State variable to manage category choice.
  const [categoryChoice, setCategoryChoice] = useState(null);
  //State variable to manage the compost bin created by users when added to.
  const [compostBin, setCompostBin] = useState([]);

  //function to update state within the textbox.
  function onSearchFormChange(event) {
    setSearchTerm(event.target.value);
  }

  //function for category choice
  function categoryChoiceFunction(selectedButton) {
    setCategoryChoice(selectedButton);
  }

  //function for compostbin adding items using spreader.
  function compostBinAdd(foodItem) {
    setCompostBin([...compostBin, foodItem]);
  }

  //function for emptying the bin completely just resets to emppty array.
  function emptyCompostBin() {
    setCompostBin([]);
  }

  // function to find object based on ID which is unique to each object.
  function findObjectIndex(needle) {
    return function (haystack) {
      return haystack.ID === needle.ID;
    };
  }

  //function for removing item from basket using spread and slicing.
  function removeFoodItemFromCompostBin(foodItem) {
    let n = compostBin.findIndex(findObjectIndex(foodItem));
    setCompostBin([
      ...compostBin.slice(0, n),
      ...compostBin.slice(n + 1, compostBin.length),
    ]);
  }

  useEffect(() => {
    async function fetchData() {
      const URL =
        "https://raw.githubusercontent.com/GaCampion/Project-Sustainability-App/main/COMPOSTDATAFINAL.json";
      try {
        const response = await fetch(URL);
        const composte = await response.json();
        setLoading(true);
        setData(composte);
      } catch (error) {
        setError(error);
        setLoading(false);
      }
    }

    fetchData();
  }, []);
  if (error) {
    return <h1>Opps! An error has occurred: {error.toString()}</h1>;
  } else if (loading === false) {
    return <h1>Waiting for the data ...... waiting....</h1>;
  } else {
    return (
      <>
        <div className="container-fluid text-center bg-light">
          <img src={CompostBinImg} alt="CompostBin" class="img-fluid" />
          <header className=""></header>
          {/*Conditional rendering of compost bin and remove button based on anything being placed in bin*/}
          {/*Proping compostBin data and remove item function*/}
          {compostBin.length > 0 && (
            <CompostBin
              compostBin={compostBin}
              remove={removeFoodItemFromCompostBin}
            />
          )}
          {/*Button click will call the emptyCompostBin function*/}
          {compostBin.length > 0 && (
            <button class="btn btn-danger" onClick={() => emptyCompostBin()}>
              Remove All
            </button>
          )}
          <br /> <br />
          {/*SummariseBin proping compostBin data*/}
          <SummariseBin compostBin={compostBin} />
          {/*Category buttons will call the category choice function*/}
          <button
            type="button"
            class="btn btn-success btn-sm"
            onClick={() => categoryChoiceFunction("Food Waste")}
          >
            Food Waste
          </button>
          &nbsp;
          <button
            type="button"
            class="btn btn-success btn-sm"
            onClick={() => categoryChoiceFunction("Pantry")}
          >
            Pantry
          </button>
          &nbsp;
          <button
            type="button"
            class="btn btn-success btn-sm"
            onClick={() => categoryChoiceFunction("Grain")}
          >
            Grain
          </button>
          &nbsp;
          <button
            type="button"
            class="btn btn-success btn-sm"
            onClick={() => categoryChoiceFunction("Vegetable")}
          >
            Vegetable
          </button>
          &nbsp;
          <button
            type="button"
            class="btn btn-success btn-sm"
            onClick={() => categoryChoiceFunction("Fruit")}
          >
            Fruit
          </button>
          &nbsp;
          <button
            type="button"
            class="btn btn-success btn-sm"
            onClick={() => categoryChoiceFunction("Dairy")}
          >
            Dairy
          </button>
          &nbsp;
          <button
            type="button"
            class="btn btn-success btn-sm"
            onClick={() => categoryChoiceFunction("Legume")}
          >
            Legume
          </button>
          &nbsp;
          <button
            type="button"
            class="btn btn-success btn-sm"
            onClick={() => categoryChoiceFunction("Plant-Based")}
          >
            Plant-Based
          </button>
          &nbsp;
          <button
            type="button"
            class="btn btn-warning btn-sm"
            onClick={() => categoryChoiceFunction(null)}
          >
            Reset Choice
          </button>
          &nbsp;
          <hr />
          <form className="search-box">
            <input
              class="form-control"
              onChange={onSearchFormChange}
              type="text"
              placeholder="Please enter the food items to search here..."
            />
          </form>
          {/*Child component that props the compostbin/category choice data and the adding to compost bin function*/}
          <CompostResults
            search={searchTerm}
            compostArray={data}
            choice={categoryChoice}
            addItem={compostBinAdd}
          />
          <br /> <br />
          <hr class="hr" />
          <div>
            <h2>What Type Of Compost Bin Do You Need?</h2>
            {/*Selection box for different compost bins. Not proping from this parent component as fetching its own standalone data from a different json*/}
            <CompostBinSelector />
          </div>
        </div>
      </>
    );
  }
}

export default CompostBinMain;

import React from "react";

function SummariseBin(props) {
  // function matches the given item based on ID and Name.
  function searchBin(needle) {
    return function (haystack) {
      return haystack.ID === needle.ID && haystack.Name === needle.Name;
    };
  }

  let summary = [];

  // Handle empty compost bin
  if (props.compostBin.length <= 0) {
    summary = [];
  } else if (props.compostBin.length === 1) {
    // If there is only one item, create a summary entry with a quantity of 1
    summary[0] = {
      qty: 1,
      ID: props.compostBin[0].ID,
      Name: props.compostBin[0].Name,
    };
  } else {
    // Initialize the summary with the first item
    summary[0] = {
      qty: 1,
      ID: props.compostBin[0].ID,
      Name: props.compostBin[0].Name,
    };

    // Loop through each item in the compost bin starting from the second item
    for (let i = 1; i < props.compostBin.length; i++) {
      let indexPos = summary.findIndex(searchBin(props.compostBin[i]));

      if (indexPos >= 0) {
        // If the item is already in the summary, increment its quantity
        summary[indexPos] = {
          ...summary[indexPos],
          qty: summary[indexPos].qty + 1,
        };
      } else {
        // If the item is not in the summary, add it with a quantity of 1
        summary.push({
          qty: 1,
          ID: props.compostBin[i].ID,
          Name: props.compostBin[i].Name,
        });
      }
    }
  }

  return (
    <>
      {summary.length > 0 && (
        <>
          <h1>Your summarised Compost Bin</h1>
          <table className="table table-hover table-striped table-bordered">
            <thead className="table-success">
              <tr>
                <th>Name</th>
                <th>Quantity</th>
              </tr>
            </thead>
            <tbody>
              {summary.map((c, index) => (
                <tr key={index}>
                  <td>
                    <b>{c.Name}</b>
                  </td>
                  <td>
                    <b>{c.qty}</b>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <br /> <br />
        </>
      )}
    </>
  );
}
export default SummariseBin;

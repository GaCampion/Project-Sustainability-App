function CompostResults(props) {
  //ascending sort function
  function compareNameAsc(itemA, itemB) {
    let comparison = 0;
    let itemAStr = itemA.Name.toLowerCase();
    let itemBStr = itemB.Name.toLowerCase();

    if (itemAStr > itemBStr) comparison = 1;
    else if (itemAStr < itemBStr) comparison = -1;
    else comparison = 0;

    return comparison;
  }

  //filter based on category
  function categoryFilter(category) {
    return function (compostObject) {
      return compostObject.Category === category;
    };
  }

  //filter function bsaed on name/category input etc.
  function compostFilterFunction(searchTerm) {
    return function (object) {
      let name = object.Name.toLowerCase();
      let category = object.Category.toLowerCase();
      let decompositionTime = object["Decomposition Time (days)"].toString();
      let compostabilityRating = object["Compostability Rating"].toString();
      let carbonNitrogenRatio =
        object["Carbon-to-Nitrogen Ratio (C:N)"].toString();
      let environmentRating =
        object["Environmental Impact Rating"].toLowerCase();

      return (
        searchTerm !== "" &&
        (name.includes(searchTerm.toLowerCase()) ||
          decompositionTime === searchTerm ||
          compostabilityRating === searchTerm ||
          carbonNitrogenRatio === searchTerm ||
          environmentRating === searchTerm ||
          category.includes(searchTerm.toLowerCase()))
      );
    };
  }

  // Start with the original array
  let filteredArray = props.compostArray;

  // Apply category filter if a category is chosen
  if (props.choice) {
    filteredArray = filteredArray.filter(categoryFilter(props.choice));
  }

  // Apply search filter if a search term is entered
  if (props.search) {
    filteredArray = filteredArray.filter(compostFilterFunction(props.search));
  }

  // Variable for holding the number of search results.
  let numberResults = filteredArray.length;

  //variable to use for conditional rendering of search.
  const displayResults = props.choice || props.search;
  return (
    <>
      {displayResults && (
        <>
          <br /> <br />
          {/*Conditional rendering of result comments based on the length of the array*/}
          {numberResults > 0 && <h2> There are {numberResults} options </h2>}
          <h3>
            {numberResults === 0 && (
              <p> You have no options for your compost bin.</p>
            )}
            {numberResults > 0 && numberResults <= 10 && (
              <p> You have some options for your compost bin. </p>
            )}
            {numberResults > 10 && numberResults <= 30 && (
              <p>
                {" "}
                You have many options for your compost bin, use the search bar
                to specify further.{" "}
              </p>
            )}
            {numberResults > 30 && numberResults <= 100 && (
              <p>
                {" "}
                You have several options, use the search bar to specify further.{" "}
              </p>
            )}
          </h3>
          <br /> <br />
          <div className="card-container">
            {/*Filtering and sorting being applied before mapping of information*/}
            {filteredArray.sort(compareNameAsc).map((c, index) => (
              <div key={index} className="item">
                <div className="image-container">
                  <img src={c.Image} alt="Your Image" className="image" />
                </div>
                <div className="property-sections">
                  <div>
                    <p>
                      <b>Name: </b> {c.Name}
                    </p>
                    <p>
                      <b>Category: </b> {c.Category}
                    </p>
                    <p>
                      <b>Decomposition: </b> {c["Decomposition Time (days)"]}{" "}
                      days
                    </p>
                    <p>
                      <b>Compostability Rating: </b>{" "}
                      {c["Compostability Rating"]}
                    </p>
                    <p>
                      <b>Carbon-to-Nitrogen Ratio: </b>
                      {c["Carbon-to-Nitrogen Ratio (C:N)"]}
                    </p>
                    <p>
                      <b>Environmental Rating: </b>
                      {c["Environmental Impact Rating"]}
                    </p>
                  </div>
                  <hr />
                  <div>
                    {/*Add to bin button that is proping the add functionality from the parent component*/}
                    <button
                      type="button"
                      class="btn btn-success btn-sm"
                      onClick={() => props.addItem(c)}
                    >
                      Add to Bin
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </>
  );
}

export default CompostResults;

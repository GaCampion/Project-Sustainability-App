export const crops = [
  {
    name: "Carrots",
    type: "Vegetable",
    description:
      "Carrots are root vegetables known for their bright orange color and sweet taste. They are a good source of vitamins and beta-carotene.",
    Environment:
      "Choose well-drained soil, remove stones and debris, keep soil consistently moist not waterlogged, and enough sunlight throught the day.",
    Harvesting:
      "Carrots are usually ready for harvest between 60-80 days after planting, depending on the variety.",
  },
  {
    name: "Apple",
    type: "Fruit",
    description:
      "Apples are a popular fruit with a sweet and crisp taste. They come in various colors and are a great source of fiber and antioxidants.",
    Environment:
      "Thrive in well-drained soil and full of sunlight, plant trees in late winter, early spring, apply fertilizer as tree starts to grow, remove disease or dead branches.",
    Harvesting: "Typically ready for harvesting in late summer through fall.",
  },
  {
    name: "Pear",
    type: "Fruit",
    description:
      "Pears are good source of vitamin C, potassium and fiber, and also support overall heart and gut health.",
    Environment:
      "Mainly for European Climate, plant bare-root trees in late winter or early spring while the tree is dormant, with well-draining soil and full sunlight. ",
    Harvesting:
      "Pears are typically ready for harvesting in late summer to early fall. Harvest when the fruit is firm, but not yet fully ripe.",
  },
  {
    name: "Orange",
    type: "Fruit",
    description:
      "Oranges are excellent source of vitamin C, eating oranges helps with skin health, regulating blood sugar and supports digestive health.",
    Environment:
      "Oranges thrive in warm climates. They require plenty of sunlight and well-drained soil, plant trees in spring to early summer, protect trees as cold weather and frost can damage the trees.",
    Harvesting:
      "Oranges typically ripen in the late fall through winter. Harvest when the fruits reach the desired color and are firm and juicy.",
  },
  {
    name: "Watermelon",
    type: "Fruit",
    description:
      "Watermelon is a refreshing and hydrating fruit, known for its juicy, sweet flesh. It's rich in vitamins A and C, and provides a cooling sensation, making it a popular choice in hot weather.",
    Environment:
      "Watermelons thrive in warm climates. Plant seeds or seedlings in well-drained soil with plenty of sunlight. Regular watering is essential for optimal growth.",
    Harvesting:
      "Watermelons are typically ready for harvesting in late summer. Harvest when the underside of the fruit turns yellow, and the stem starts to dry and turn brown.",
  },
  {
    name: "Blueberries",
    type: "Fruit",
    description:
      "Blueberries are small, sweet berries that are rich in antioxidants, vitamins, and minerals. They are known for their potential health benefits, including improving heart health and cognitive function.",
    Environment:
      "Blueberries prefer acidic soil. Plant bushes in a sunny location with well-draining soil. Mulching and regular watering are important for blueberry plants.",
    Harvesting:
      "Blueberries are typically ready for harvesting in summer. Harvest when the berries are plump, firm, and have a deep blue color.",
  },
  {
    name: "Grapes",
    type: "Fruit",
    description:
      "Grapes are versatile fruits used for making wine, juices, and snacks. They are rich in antioxidants and may offer various health benefits, including heart health and immune support.",
    Environment:
      "Grapes thrive in well-drained soil and full sunlight. Plant vines in spring to early summer. Pruning and training are important for grapevine maintenance.",
    Harvesting:
      "Grapes are typically ready for harvesting in late summer to early fall. Harvest when the grapes are plump, juicy, and have reached the desired sweetness.",
  },
  {
    name: "Raspberry",
    type: "Fruit",
    description:
      "Raspberries are delicious and nutritious berries that are rich in vitamins, antioxidants, and fiber. They are known for their vibrant color and sweet-tart flavor.",
    Environment:
      "Raspberries prefer well-drained soil with a slightly acidic to neutral pH. Plant bushes in a sunny location and provide support for trailing varieties. Regular pruning is essential for raspberry plants.",
    Harvesting:
      "Raspberries are typically ready for harvesting in summer. Harvest when the berries are plump, easily come off the stem, and have a deep color.",
  },
  {
    name: "Potatoes",
    type: "Vegetable",
    description:
      "Potatoes are a good source of vitamins, high-carbohydrate and rich in potassium.",
    Environment:
      "Plant potatoes in early spring after the last frost date in your area. Prefer Cool weather for sprouting and growth.",
    Harvesting:
      "When the foliage turns yellow and dies back, typically about 2-4 weeks after flowering. Carefully dig around the plants to avoid damaging the tubers.",
  },
  {
    name: "Lemon",
    type: "Fruit",
    description:
      "Lemons are bright yellow citrus fruits, are packed with vitamin C and antioxidants.",
    Environment:
      "Thrive in warm climates, If you're in a colder region, consider growing lemon trees in containers with plenty of sunlight and protection from winds.",
    Harvesting:
      "Lemons can be harvested year-round, with most varieties ripening in the winter or early spring. Harvest when the fruit reaches the desired color and size.",
  },
  {
    name: "Strawberry",
    type: "Fruit",
    description:
      "Strawberries are vibrant red, heart-shaped fruits, serve as a refreshing addition to desserts  or smoothies, are rich in vitamin C.",
    Environment:
      "Plant in early spring or late summer, apply fertilizer when planting, prevent diseases by maintaining good air circulation.",
    Harvesting:
      "Harvest ripe strawberries by picking them when fully red. Gently remove them, keeping the caps intact.",
  },
  {
    name: "Tomatoes",
    type: "Vegetable",
    description:
      "Tomatoes are versatile, adding flavor and nutrients to various dishes, high in vitamin C, potassium and can help lower blood pressure.",
    Environment:
      "Choose a sunny location with well-draining soil, consistent watering is crucial for plants, aim to keep soil moist.",
    Harvesting:
      "Tomatoes are typically ready for picking 60-80 days after planting, depending on the variety.",
  },
  {
    name: "Beetroot",
    type: "Vegetable",
    description:
      "Beetroots are root vegetables with an earthy flavor, packed with essential nutrients like folate, manganese, and antioxidants.",
    Environment:
      "Grow in well-drained, loose soil with consistent moisture. Full sun to partial shade is suitable. Protect from frost.",
    Harvesting:
      "Harvest beetroot when they reach the size of a tennis ball or desired size, usually about 60 days after sowing.",
  },
  {
    name: "Pumpkin",
    type: "Vegetable",
    description:
      "Pumpkins are large, vine-growing vegetables known for their sweet flavor. They are rich in vitamins and make a great ingredient for various dishes.",
    Environment:
      "Plant pumpkins in rich soil with good drainage, full sun, and plenty of space for vines to spread. Protect from pests and diseases.",
    Harvesting:
      "Harvest when the pumpkin reaches a deep, solid color and the rind is hard. Typically, it takes about 75-100 days to mature.",
  },
  {
    name: "Cherry Tomatoes",
    type: "Vegetable",
    description:
      "Cherry tomatoes are small, bite-sized fruits bursting with sweetness. They are a popular choice for salads, snacking, and preserving.",
    Environment:
      "Plant in well-draining soil with plenty of sunlight. Water consistently and provide support for the vines as they grow.",
    Harvesting:
      "Harvest when cherry tomatoes are fully colored, firm, and have a slight give when squeezed. Typically, they're ready in 60-80 days.",
  },
  {
    name: "Mushroom",
    type: "Vegetable",
    description:
      "Mushrooms are fungi known for their earthy, rich taste. They're a good source of protein, vitamins, and minerals.",
    Environment:
      "Mushrooms are typically grown indoors or in shaded, humid areas. Control temperature, humidity, and light exposure for different mushroom varieties.",
    Harvesting:
      "Harvest mushrooms by gently twisting or cutting them off at the base once they reach the desired size. Harvesting periods vary based on mushroom type.",
  },
  {
    name: "Beans",
    type: "Vegetable",
    description:
      "Beans come in various types—green beans, snap beans, and more—rich in fiber, vitamins, and minerals.",
    Environment:
      "Plant in well-draining soil with ample sunlight. Provide support for climbing varieties. Water consistently without over-soaking the soil.",
    Harvesting:
      "Harvest when beans are firm, crisp, and about the size of a pencil. This usually occurs about 50-60 days after planting.",
  },
  {
    name: "Basil",
    type: "Vegetable",
    description:
      "Basil is a fragrant herb commonly used in cooking. It's rich in antioxidants, essential oils, and adds a distinctive flavor to dishes.",
    Environment:
      "Grow basil in well-draining soil with ample sunlight. Pinch off flowers to encourage leaf growth and prevent the plant from turning bitter.",
    Harvesting:
      "Harvest basil leaves when the plant reaches a height of about 6 inches. Regularly prune the plant to encourage bushier growth.",
  },
  {
    name: "Peppers",
    type: "Vegetable",
    description:
      "Peppers come in various colors and levels of spiciness. They are rich in vitamins, especially vitamin C.",
    Environment:
      "Plant in well-draining soil with full sunlight. Provide support for taller varieties. Water consistently without over-watering.",
    Harvesting:
      "Harvest peppers once they reach full size and desired color. Typically, harvesting can start 60-90 days after planting.",
  },
  {
    name: "Onion",
    type: "Vegetable",
    description:
      "Onions are pungent, flavorful bulbs that are used in a variety of dishes. They contain antioxidants and have various health benefits.",
    Environment:
      "Plant in well-draining soil with full sun exposure. Water regularly but avoid over-watering. Mulch to prevent weed growth.",
    Harvesting:
      "Harvest when the tops turn yellow and start to fall over. This is typically around 100-120 days after planting.",
  },
  {
    name: "Cucumber",
    type: "Vegetable",
    description:
      "Cucumbers are refreshing, mild-flavored vegetables high in hydration. They are rich in vitamins and make a great addition to salads.",
    Environment:
      "Plant in well-draining, fertile soil with full sun. Provide support for vines. Keep consistently moist but not waterlogged.",
    Harvesting:
      "Harvest when the cucumbers are firm, crisp, and have reached the desired size. This is usually around 50-70 days after planting.",
  },
  {
    name: "Broccoli",
    type: "Vegetable",
    description:
      "Broccoli is a nutritious vegetable, rich in vitamins, antioxidants, and fiber. It's known for its green, edible flower head.",
    Environment:
      "Plant in fertile, well-draining soil with full sun. Keep the soil consistently moist and protect from pests.",
    Harvesting:
      "Harvest broccoli when the heads are tight, dark green, and about 6-8 inches in diameter. Typically ready in 60-100 days.",
  },
  {
    name: "Lettuce",
    type: "Vegetable",
    description:
      "Lettuce is a leafy green vegetable often used in salads. It's rich in vitamins and minerals and comes in various forms like romaine, butterhead, and leaf.",
    Environment:
      "Grow lettuce in well-draining soil with partial shade in warmer climates. Keep the soil consistently moist and avoid letting it dry out.",
    Harvesting:
      "Harvest lettuce by picking the outer leaves when they're large enough to eat. Alternatively, harvest the entire head when mature, typically around 50-70 days.",
  },
];

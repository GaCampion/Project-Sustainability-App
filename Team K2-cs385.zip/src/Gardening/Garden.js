import React, { useEffect, useState } from "react";
import Styles from "./Garden.css";
import { crops } from "./crops";
import Vegetable from "./Vegetable";
import Fruit from "./Fruit";

//Importing Images for Garden Page
import fruit from "./Images/fruit.jpg";
import veg from "./Images/veg.jpg";

function Garden() {
  // Function to show more Fruit or Veg when the button is clicked
  // I have set the useState as "" as we are either taking a string fruit it will show category fruit
  // Else it will take in a string Veg and show category Vegetables.
  const [showDetails, setShowDetails] = useState("");
  const handleButtonClick = (category) => {
    setShowDetails((showDetails) => (showDetails === category ? "" : category));
  };

  //Searching Fruit/Veg using uesState "" as we are taking in a string from the User
  const [searchTerm, setSearchTerm] = useState("");
  //This function updates searchTerm as the user is inputing values.
  function onSearchFormChange(event) {
    setSearchTerm(event.target.value);
  }
  //Filters the searchTerm by NAME from Crops DataSet as the user is inputing either Fruit or Vegetable NAME
  const filteredItems = crops.filter((item) =>
    item.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div>
      {/* Search Box  for Fruit Veg*/}
      <header className="GardenHeader">
        <h2>Find Fruit and Vegetables to Grow</h2>
        <input
          className="searchbox"
          type="text"
          placeholder="What do you want to grow?"
          value={searchTerm}
          onChange={onSearchFormChange}
        />
      </header>
      <div>
        {/* Mapping out the name of Fruit and Veg when User uses Searchbox */}
        {searchTerm &&
          (filteredItems.length === 0 ? (
            <p>
              <b>No items found</b>
            </p>
          ) : (
            filteredItems.map((item) => (
              <div key={item.name}>
                <h3>{item.name}</h3>
                <div>
                  <p>
                    <strong>Description:</strong> {item.description}
                  </p>
                  <p>
                    <strong>Environment:</strong> {item.Environment}
                  </p>
                  <p>
                    <strong>Harvesting:</strong> {item.Harvesting}
                  </p>
                </div>
              </div>
            ))
          ))}
      </div>
      {/*
          Displaying the 2 Images and the Buttons
          Using bootstrap for styling, and layout
      */}
      <footer className="GardenFooter">
        <div className="container">
          <div className="row">
            <div className="col-sm-6">
              <img src={fruit} alt="Fruit Image" className="img-fluid aFruit" />
              <button
                onClick={() => handleButtonClick("fruit")}
                className="btn btn-primary buttonA"
              >
                {showDetails === "fruit" ? "Hide Fruit" : "Grow Fruit"}
              </button>
            </div>

            <div className="col-sm-6">
              <img src={veg} alt="Veg Image" className="img-fluid aVeg" />
              <button
                onClick={() => handleButtonClick("veg")}
                className="btn btn-primary buttonA"
              >
                {showDetails === "veg" ? "Hide Vegetable" : "Grow Vegetable"}
              </button>
            </div>
          </div>
        </div>
        {showDetails === "fruit" && <Fruit />}
        {showDetails === "veg" && <Vegetable />}
      </footer>
    </div>
  );
}
export default Garden;

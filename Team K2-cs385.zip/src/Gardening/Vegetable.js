//Importing React library and useState / and Crops Data
import React, { useState } from "react";
import { crops } from "./crops";

//Importing all the Images from the folder Gardening / Images / Veg
import Cucumber from "./Images/Veg/Cucumber.jpg";
import basil from "./Images/Veg/basil.jpg";
import beans from "./Images/Veg/beans.jpg";
import beetroot from "./Images/Veg/beetroot.jpg";
import broccoli from "./Images/Veg/broccoli.jpg";
import carrot from "./Images/Veg/carrot.jpg";
import cherryTomatoes from "./Images/Veg/cherry-tomatoe.jpg";
import lettuce from "./Images/Veg/lettuce.jpg";
import mushroom from "./Images/Veg/mushroom.jpg";
import onion from "./Images/Veg/onion.jpg";
import peppers from "./Images/Veg/peppers.jpg";
import potatoe from "./Images/Veg/potatoe.jpg";
import pumpkin from "./Images/Veg/pumpkin.jpg";
import tomatoe from "./Images/Veg/tomatoe.jpg";

function Vegetable() {
  //Variable to filter by Veg from the crops data
  const vegetables = crops.filter((item) => item.type === "Vegetable");

  //Allows images of the Veg to be clicked so it shows description / hides description
  const [selectedVeg, setSelectedVeg] = useState(null);

  //Button Function to show description of Veg and map out the data from Crops.
  const handleVegClick = (veg) => {
    setSelectedVeg((selectedVeg) => {
      //Allows us to hide the description and show it again if it's clicked
      if (selectedVeg === veg) {
        return null;
      } else {
        return veg;
      }
    });
  };
  return (
    // In this code we are using bootstrap for styling the layout
    // As well CSS to keep images the same size
    <div className="container-fluid">
      <h2>Vegetables</h2>
      <div className="row">
        {vegetables.map((veg, index) => (
          <div
            key={index}
            onClick={() => handleVegClick(veg)}
            className="col-md-4 mb-4"
          >
            {/* It maps out and retrieves Veg name from crops and shows images. 
                 and maps out the details for the Veg once image is clicked 
             */}
            <div className="text-center">
              {veg.name === "Cucumber" && (
                <img
                  src={Cucumber}
                  alt="Cucumber"
                  className="img-fluid vegImg"
                />
              )}
              {veg.name === "Basil" && (
                <img src={basil} alt="basil" className="img-fluid vegImg" />
              )}
              {veg.name === "Beans" && (
                <img src={beans} alt="beans" className="img-fluid vegImg" />
              )}
              {veg.name === "Beetroot" && (
                <img
                  src={beetroot}
                  alt="beetroot"
                  className="img-fluid vegImg"
                />
              )}
              {veg.name === "Broccoli" && (
                <img
                  src={broccoli}
                  alt="broccoli"
                  className="img-fluid vegImg"
                />
              )}
              {veg.name === "Carrots" && (
                <img src={carrot} alt="carrot" className="img-fluid vegImg" />
              )}
              {veg.name === "Cherry Tomatoes" && (
                <img
                  src={cherryTomatoes}
                  alt="cherryTomatoes"
                  className="img-fluid vegImg"
                />
              )}
              {veg.name === "Lettuce" && (
                <img src={lettuce} alt="lettuce" className="img-fluid vegImg" />
              )}
              {veg.name === "Mushroom" && (
                <img
                  src={mushroom}
                  alt="mushroom"
                  className="img-fluid vegImg"
                />
              )}
              {veg.name === "Onion" && (
                <img src={onion} alt="onion" className="img-fluid vegImg" />
              )}
              {veg.name === "Peppers" && (
                <img src={peppers} alt="peppers" className="img-fluid vegImg" />
              )}
              {veg.name === "Potatoes" && (
                <img src={potatoe} alt="potatoe" className="img-fluid vegImg" />
              )}
              {veg.name === "Pumpkin" && (
                <img src={pumpkin} alt="pumpkin" className="img-fluid vegImg" />
              )}
              {veg.name === "Tomatoes" && (
                <img src={tomatoe} alt="tomatoe" className="img-fluid vegImg" />
              )}
              <h3>{veg.name}</h3>
            </div>
            {/* When clicked it Displays details of the selected Vegetables on click */}
            {selectedVeg === veg && (
              <div className="text-center">
                <p>
                  <strong>Description:</strong> {selectedVeg.description}
                </p>
                <p>
                  <strong>Environment:</strong> {selectedVeg.Environment}
                </p>
                <p>
                  <strong>Harvesting:</strong> {selectedVeg.Harvesting}
                </p>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
export default Vegetable;

//Importing React library and useState / and Crops Data
import React, { useState } from "react";
import { crops } from "./crops";

//Importing all the Fruit Images from Gardening / Images / Fruit
import apple from "./Images/Fruit/apple.jpg";
import pear from "./Images/Fruit/pear.jpg";
import orange from "./Images/Fruit/orange.jpg";
import lemon from "./Images/Fruit/lemon.jpg";
import strawberry from "./Images/Fruit/strawberry.jpg";
import blueberries from "./Images/Fruit/Blueberrie.jpg";
import grape from "./Images/Fruit/Grape.jpg";
import raspberry from "./Images/Fruit/raspberry.jpg";
import watermelon from "./Images/Fruit/watermelon.jpg";

function Fruit() {
  //Variable to filter by Type = "Fruit" from the crops data
  const fruits = crops.filter((item) => item.type === "Fruit");

  //Allows images of the fruit to be clicked so it shows description / hides description
  const [selectedFruit, setSelectedFruit] = useState(null);

  //Button Function to show description of fruit and map out the data from Crops.
  const handleFruitClick = (fruit) => {
    setSelectedFruit((selectedFruit) => {
      //Allows us to hide the description and show it again if it's clicked
      if (selectedFruit === fruit) {
        return null;
      } else {
        return fruit;
      }
    });
  };

  return (
    // In this code we are using bootstrap for styling the layout
    // As well CSS to keep images the same size
    <div className="container-fluid">
      <h2>Fruit</h2>
      <div className="row">
        {/*  It maps out fruit name from crops and shows images.
             maps out the details for the fruit once image is clicked 
        */}
        {fruits.map((fruit, index) => (
          <div
            key={index}
            className="col-md-4 mb-4"
            onClick={() => handleFruitClick(fruit)}
          >
            <div className="text-center">
              {fruit.name === "Apple" && (
                <img src={apple} alt="Apple" className="img-fluid fruitImg" />
              )}
              {fruit.name === "Pear" && (
                <img src={pear} alt="Pear" className="img-fluid fruitImg" />
              )}
              {fruit.name === "Orange" && (
                <img src={orange} alt="Orange" className="img-fluid fruitImg" />
              )}
              {fruit.name === "Lemon" && (
                <img src={lemon} alt="Lemon" className="img-fluid fruitImg" />
              )}
              {fruit.name === "Strawberry" && (
                <img
                  src={strawberry}
                  alt="Strawberry"
                  className="img-fluid fruitImg"
                />
              )}
              {fruit.name === "Blueberries" && (
                <img
                  src={blueberries}
                  alt="Blueberrie"
                  className="img-fluid fruitImg"
                />
              )}
              {fruit.name === "Grapes" && (
                <img src={grape} alt="grape" className="img-fluid fruitImg" />
              )}
              {fruit.name === "Raspberry" && (
                <img
                  src={raspberry}
                  alt="raspberry"
                  className="img-fluid fruitImg"
                />
              )}
              {fruit.name === "Watermelon" && (
                <img
                  src={watermelon}
                  alt="watermelon"
                  className="img-fluid fruitImg"
                />
              )}
              <h3>{fruit.name}</h3>
            </div>
            {/* Display additional details only if selectedFruit matches the current fruit*/}
            {selectedFruit === fruit && (
              <div className="text-center">
                <p>
                  <strong>Description:</strong> {selectedFruit.description}
                </p>
                <p>
                  <strong>Environment:</strong> {selectedFruit.Environment}
                </p>
                <p>
                  <strong>Harvesting:</strong> {selectedFruit.Harvesting}
                </p>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
export default Fruit;
